// Runs after "cap sync": makes the native launch screen blank (matches the app's own loading screen)
const fs = require('fs'), path = require('path');
const res = path.join('android', 'app', 'src', 'main', 'res');
if (!fs.existsSync(res)) process.exit(0);
fs.mkdirSync(path.join(res, 'drawable'), { recursive: true });
fs.writeFileSync(path.join(res, 'drawable', 'splash_empty.xml'),
`<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24"><path android:fillColor="#00000000" android:pathData="M0,0h1v1h-1z"/></vector>
`);
const style = (bg) => `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme.NoActionBarLaunch" parent="AppTheme.NoActionBar">
        <item name="android:background">@drawable/splash</item>
        <item name="android:windowSplashScreenBackground">${bg}</item>
        <item name="android:windowSplashScreenAnimatedIcon">@drawable/splash_empty</item>
    </style>
</resources>
`;
const day = path.join(res, 'values', 'styles.xml');
let s = fs.readFileSync(day, 'utf8');
if (!s.includes('windowSplashScreenBackground')) {
  s = s.replace(/<style name="AppTheme.NoActionBarLaunch"[^>]*>[\s\S]*?<\/style>/, style('#fbf6ef').match(/<style[\s\S]*<\/style>/)[0]);
  fs.writeFileSync(day, s);
}
fs.mkdirSync(path.join(res, 'values-night'), { recursive: true });
fs.writeFileSync(path.join(res, 'values-night', 'styles.xml'), style('#1d2321'));
console.log('Patched splash theme');
