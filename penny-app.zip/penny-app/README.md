# Penny – build the APK
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder (keep the .github folder).
3. Open the Actions tab, wait for "Build APK" to finish (~5 min).
4. Open the run, download the "Penny-apk" artifact, unzip it, and install app-debug.apk on your phone.

Local build (needs Node 20, JDK 17, Android SDK):
npm install && npx cap add android && npx capacitor-assets generate --android && npx cap sync android && cd android && ./gradlew assembleDebug
